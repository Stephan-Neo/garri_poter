$(document).ready(function () {
    $('.theme').click(function () {
        $('.wrapper').toggleClass('white');
        $('.content__wrapper').toggleClass('white');
        $('.link').toggleClass('white');
        $('.theme').toggleClass('white');
    });
});